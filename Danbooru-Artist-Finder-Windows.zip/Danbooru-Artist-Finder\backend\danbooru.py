from __future__ import annotations

import email.utils
import json
import random
import socket
import time
from datetime import datetime, timezone
from typing import Callable
from urllib.parse import urlparse

import httpx

from .config import (
    BACKOFF_SECONDS, MAX_RETRIES, POST_FIELDS, REQUEST_TIMEOUT_SECONDS, RETRY_AFTER_CAP_SECONDS, TAG_FIELDS, USER_AGENT,
)

NETWORK_FAILURE = "Danbooru 연결에 실패했습니다. 네트워크/VPN 상태를 확인한 뒤 다시 시도하세요."
# Shown after every retry failed; the reason is appended for the log and the status line.
FAILURE_MESSAGES = {
    "timeout": f"{NETWORK_FAILURE} (응답 시간 초과)",
    "connection_reset": f"{NETWORK_FAILURE} (연결 끊김)",
    "dns": f"{NETWORK_FAILURE} (DNS 조회 실패)",
    "connection": NETWORK_FAILURE,
    "rate_limit": "Danbooru 요청 한도(429)에 걸렸습니다. 잠시 뒤 다시 시도하세요.",
    "server": "Danbooru 서버가 일시적으로 응답하지 않습니다 (5xx). 잠시 뒤 다시 시도하세요.",
    "malformed_json": "Danbooru가 올바르지 않은 JSON을 반환했습니다.",
}


class DanbooruError(RuntimeError):
    """kind: timeout, connection_reset, dns, connection, rate_limit, server, malformed_json
    (all retried first) or forbidden, page_limit, client (never retried)."""

    def __init__(self, kind: str, message: str, status_code: int | None = None):
        super().__init__(message)
        self.kind = kind
        self.status_code = status_code


class SearchStopped(Exception):
    """The user pressed 중지 while a retry wait was in progress."""


def validate_danbooru_host(value: str) -> str:
    parsed = urlparse(value.strip())
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "https" or not (host == "donmai.us" or host.endswith(".donmai.us")):
        raise ValueError("Danbooru host는 https://*.donmai.us 형식이어야 합니다.")
    return f"https://{host}"


def retry_after_seconds(value: str | None, now: datetime | None = None) -> float | None:
    if not value:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        try:
            parsed = email.utils.parsedate_to_datetime(value)
            current = now or datetime.now(timezone.utc)
            return max(0.0, (parsed - current).total_seconds())
        except (TypeError, ValueError, OverflowError):
            return None


def is_dns_failure(exc: BaseException) -> bool:
    current: BaseException | None = exc
    for _ in range(6):
        if current is None:
            break
        if isinstance(current, socket.gaierror):
            return True
        text = str(current).lower()
        if "getaddrinfo" in text or "name or service not known" in text or "nodename nor servname" in text:
            return True
        current = current.__cause__ or current.__context__
    return False


def server_message(response: httpx.Response) -> str:
    try:
        message = response.json().get("message")
    except (ValueError, AttributeError):
        return ""
    return str(message)[:200] if message else ""


class DanbooruClient:
    """Read-only posts.json / tags.json client. One request plus at most `max_retries`
    retries per call, never more; `sleep` is the (interruptible) wait used between attempts."""

    def __init__(
        self,
        host: str,
        *,
        transport=None,
        sleep: Callable[[float], None] = time.sleep,
        jitter: Callable[[], float] = lambda: random.uniform(0, 0.25),
        max_retries: int = MAX_RETRIES,
        timeout: float = REQUEST_TIMEOUT_SECONDS,
        should_stop: Callable[[], bool] = lambda: False,
    ):
        self.host = validate_danbooru_host(host)
        self.sleep = sleep
        self.jitter = jitter
        self.max_retries = max_retries
        self.should_stop = should_stop
        self._client = httpx.Client(
            transport=transport, timeout=timeout, follow_redirects=False,
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
        )

    def close(self) -> None:
        self._client.close()

    def fetch_posts(self, *, query: str, page: int | str, limit: int, progress=lambda _: None) -> list[dict]:
        params = {"tags": query, "page": page, "limit": limit, "only": POST_FIELDS}
        return self._get_list(f"{self.host}/posts.json", params, progress)

    def fetch_post_counts(self, names: list[str], progress=lambda _: None) -> dict[str, int]:
        """Danbooru 전체 등록 작품 수 for many tags in one request (search[name_comma]).
        Names Danbooru does not return are simply absent from the result."""
        params = {"search[name_comma]": ",".join(names), "only": TAG_FIELDS, "limit": max(len(names), 1)}
        rows = self._get_list(f"{self.host}/tags.json", params, progress, quiet=True)
        return {row["name"]: row["post_count"] for row in rows
                if isinstance(row, dict) and isinstance(row.get("name"), str) and isinstance(row.get("post_count"), int)}

    def _get_list(self, url: str, params: dict, progress, quiet: bool = False) -> list:
        """GET a JSON list with bounded retries. quiet: report retries only."""
        last_kind = "connection"
        for retry in range(self.max_retries + 1):  # retry 0 is the first request
            if retry:
                progress({"phase": "retrying", "retry": retry, "max_retries": self.max_retries, "retry_kind": last_kind})
            elif not quiet:
                progress({"phase": "connecting", "retry": 0, "max_retries": self.max_retries})
            retry_after: float | None = None
            try:
                response = self._client.get(url, params=params)
                status = response.status_code
                if status == 429:
                    last_kind = "rate_limit"
                    retry_after = retry_after_seconds(response.headers.get("Retry-After"))
                elif 500 <= status <= 599:
                    last_kind = "server"
                elif status == 403:
                    raise DanbooruError("forbidden", "Danbooru가 요청을 거부했습니다 (403).", 403)
                elif status == 410:
                    # Danbooru refuses numbered pages beyond 1000 (PaginationError).
                    raise DanbooruError("page_limit", server_message(response) or "Danbooru 페이지 한도에 도달했습니다.", 410)
                elif not 200 <= status <= 299:
                    detail = server_message(response)
                    raise DanbooruError("client", f"Danbooru 요청 오류 ({status}){': ' + detail if detail else ''}", status)
                else:
                    try:
                        payload = response.json()
                    except (json.JSONDecodeError, ValueError):
                        payload = None
                    if isinstance(payload, list):
                        if not quiet:
                            progress({"phase": "connected", "retry": retry, "max_retries": self.max_retries})
                        return payload
                    last_kind = "malformed_json"
            except httpx.TimeoutException:
                last_kind = "timeout"
            except httpx.ConnectError as exc:
                last_kind = "dns" if is_dns_failure(exc) else "connection"
            except (httpx.ReadError, httpx.WriteError, httpx.RemoteProtocolError, httpx.CloseError):
                last_kind = "connection_reset"
            except httpx.TransportError:
                last_kind = "connection"
            if retry < self.max_retries:
                base = retry_after if retry_after is not None else BACKOFF_SECONDS[min(retry, len(BACKOFF_SECONDS) - 1)]
                self.sleep(min(base, RETRY_AFTER_CAP_SECONDS) + self.jitter())
                if self.should_stop():
                    raise SearchStopped()
        raise DanbooruError(last_kind, FAILURE_MESSAGES[last_kind])
