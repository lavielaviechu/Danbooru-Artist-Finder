"""Finder's local backend. Bound to 127.0.0.1 by app.py and used only by the pywebview window."""
from __future__ import annotations

import copy
import logging
import os
import threading
import uuid
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.middleware.trustedhost import TrustedHostMiddleware

from .artist_lab import ArtistLabClient, ArtistLabError
from .config import APP_NAME, DEFAULT_ARTIST_LAB_URL, DEFAULT_DANBOORU_HOST, PAGE_DELAY_SECONDS, PAGE_SCOPES
from .core import REASON_USER, Collector, build_query, normalize_query
from .danbooru import DanbooruClient
from .post_counts import PostCountLookup
from .storage import LocalStorage

ROOT = Path(__file__).resolve().parents[1]
# DAF_DATA_ROOT lets tests and smoke runs use a temporary data folder.
storage = LocalStorage(Path(os.environ.get("DAF_DATA_ROOT") or ROOT))
log = logging.getLogger("artist_finder")

DEFAULT_SETTINGS = {
    "target_count": 20,
    "page_scope": "10",
    "sfw_only": True,
    "sort_mode": "frequency",
    "exclude_seen": False,
    "exclude_artist_pool": False,
    "artist_lab_url": DEFAULT_ARTIST_LAB_URL,
    "min_post_count_enabled": False,
    "min_post_count": 10,
}

app = FastAPI(title=APP_NAME)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost"])
jobs: dict[str, dict] = {}
stop_events: dict[str, threading.Event] = {}
jobs_lock = threading.RLock()
# The current search's whole final list for 더 보기. Memory only: replaced when a new search
# starts and gone when Finder exits. The page only ever receives slices of it.
results_session: dict = {"job_id": None, "artists": []}


def result_page_size(job: dict) -> int:
    """Rows shown first and added per 더 보기: the search's 목표 작가 수."""
    return job["target_count"]


class SettingsRequest(BaseModel):
    target_count: int = Field(20, ge=1, le=500)
    page_scope: Literal["10", "25", "50", "all"] = "10"
    sfw_only: bool = True
    sort_mode: Literal["frequency", "post_count", "first_seen", "random"] = "frequency"
    exclude_seen: bool = False
    exclude_artist_pool: bool = False
    artist_lab_url: str = Field(DEFAULT_ARTIST_LAB_URL, max_length=100)
    # 등록 작품 적은 작가 제외: keep artists with Danbooru post_count >= min_post_count.
    min_post_count_enabled: bool = False
    min_post_count: int = Field(10, ge=0, le=10_000_000)


class SearchRequest(SettingsRequest):
    query: str = Field(min_length=1, max_length=500)


class LabSendRequest(BaseModel):
    artists: list[str] = Field(min_length=1, max_length=500)
    artist_lab_url: str = Field(DEFAULT_ARTIST_LAB_URL, max_length=100)


def clean_artist_names(names: list[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for raw in names:
        name = str(raw).strip()
        key = name.casefold()
        if name and key not in seen:
            result.append(name)
            seen.add(key)
    return result


def load_app_settings() -> dict:
    """Known keys only; an invalid value falls back to its default. Never starts a search."""
    raw = storage.load_settings(DEFAULT_SETTINGS)
    settings = dict(DEFAULT_SETTINGS)
    for key in DEFAULT_SETTINGS:
        try:
            settings = SettingsRequest.model_validate({**settings, key: raw.get(key, settings[key])}).model_dump()
        except Exception:
            continue
    if raw != settings:
        try:
            storage.save_settings(settings)
        except OSError:
            log.warning("settings.json could not be rewritten")
    return settings


def update_job(job_id: str, values: dict) -> None:
    with jobs_lock:
        if job_id in jobs:
            jobs[job_id].update(values)


def stop_all_jobs() -> None:
    with jobs_lock:
        for job_id, event in stop_events.items():
            jobs[job_id]["stop_requested"] = True
            event.set()


def run_search(job_id: str, request: SearchRequest, stop: threading.Event) -> None:
    try:
        _run_search(job_id, request, stop)
    finally:
        with jobs_lock:
            stop_events.pop(job_id, None)


def _run_search(job_id: str, request: SearchRequest, stop: threading.Event) -> None:
    query = build_query(request.query, request.sfw_only)
    excluded: set[str] = set()
    if request.exclude_seen:
        excluded |= storage.load_seen()
    if request.exclude_artist_pool:
        try:
            with ArtistLabClient(request.artist_lab_url) as lab:
                excluded |= set(lab.pool_names())
        except ArtistLabError as exc:
            update_job(job_id, {"status": "error", "phase": "error", "error": f"Artist Pool 제외를 적용할 수 없습니다. {exc}"})
            return

    danbooru = DanbooruClient(DEFAULT_DANBOORU_HOST, sleep=stop.wait, should_stop=stop.is_set)
    collector = Collector(danbooru, stop.wait, PAGE_DELAY_SECONDS)
    post_counts = PostCountLookup(danbooru, storage, sleep=stop.wait, delay=PAGE_DELAY_SECONDS)
    min_post_count = request.min_post_count if request.min_post_count_enabled else 0

    def progress(event: dict) -> None:
        update_job(job_id, {**event, "status": "running"})

    try:
        result = collector.collect(
            query=query, target_count=request.target_count, page_limit=PAGE_SCOPES[request.page_scope],
            sort_mode=request.sort_mode, excluded=excluded, stop_requested=stop.is_set, progress=progress,
            min_post_count=min_post_count, post_counts=post_counts,
        )
        status = "stopped" if result.stop_reason == REASON_USER else "error" if result.error else "completed"
        with jobs_lock:
            if results_session["job_id"] == job_id:
                results_session["artists"] = result.ranked
        final = {
            "status": status, "phase": "done", "artists_data": result.artists, "found": result.total_found,
            "total_results": len(result.ranked), "counts_used": result.counts_used,
            "pages": result.pages, "posts": result.posts, "requests": result.requests,
            "artists": result.total_found, "stop_reason": result.stop_reason, "partial": result.partial,
            "error": result.error, "error_kind": result.error_kind, "min_post_count": min_post_count,
            "eligible": result.eligible, "filtered_out": result.filtered_out, "count_requests": result.count_requests,
            "count_error": result.count_error,
            "count_unknown": sum(1 for item in result.ranked if item.get("post_count") is None) if result.counts_used else 0,
        }
        if status == "completed" and result.artists:
            # Only finished searches enter the history; a failed write never loses the results.
            try:
                storage.add_seen([item["name"] for item in result.artists])
            except OSError:
                log.exception("Could not save seen_artists.json")
                final["warning"] = "수집 기록을 저장하지 못했습니다. 결과는 그대로 사용할 수 있습니다."
        update_job(job_id, final)
        log.info("Search %s finished: %s, %s pages, %s posts, %s artists, %s post count requests",
                 job_id[:8], result.stop_reason, result.pages, result.posts, result.total_found, result.count_requests)
    except Exception:
        log.exception("Search failed")
        partial = collector.snapshot()
        with jobs_lock:
            if results_session["job_id"] == job_id:
                results_session["artists"] = partial
        update_job(job_id, {"status": "error", "phase": "done", "artists_data": partial[: request.target_count],
                            "found": len(partial), "total_results": len(partial), "counts_used": False,
                            "partial": True, "stop_reason": "오류",
                            "error": "검색 중 예상하지 못한 오류가 발생했습니다. logs/app.log를 확인해 주세요."})
    finally:
        danbooru.close()


@app.get("/api/bootstrap")
def bootstrap():
    settings = load_app_settings()
    seen = storage.load_seen()
    return {"settings": settings, "seen_count": len(seen), "storage_warning": storage.warning,
            "post_count_cache_count": len(storage.load_post_counts()), "danbooru_host": DEFAULT_DANBOORU_HOST}


@app.put("/api/settings")
def save_settings(body: SettingsRequest):
    payload = body.model_dump()
    try:
        ArtistLabClient(payload["artist_lab_url"]).close()
    except ArtistLabError as exc:
        raise HTTPException(400, str(exc)) from exc
    try:
        storage.save_settings(payload)
    except OSError as exc:
        raise HTTPException(500, "설정을 저장하지 못했습니다.") from exc
    return payload


@app.post("/api/search")
def start_search(body: SearchRequest):
    if not normalize_query(body.query):
        raise HTTPException(422, "검색어를 입력해 주세요.")
    with jobs_lock:
        if stop_events:
            raise HTTPException(409, "이미 검색이 진행 중입니다. 중지한 뒤 다시 시도해 주세요.")
        job_id = uuid.uuid4().hex
        page_limit = PAGE_SCOPES[body.page_scope]
        jobs[job_id] = {
            "job_id": job_id, "status": "running", "phase": "starting",
            "query_used": build_query(body.query, body.sfw_only), "sort_mode": body.sort_mode,
            "target_count": body.target_count, "page_scope": body.page_scope, "page_limit": page_limit,
            "page": 1, "pages": 0, "posts": 0, "artists": 0, "found": 0, "artists_data": [],
            "stop_requested": False, "stop_reason": "", "partial": False, "error": "", "warning": "",
            "min_post_count": body.min_post_count if body.min_post_count_enabled else 0,
        }
        stop_events[job_id] = stop = threading.Event()
        results_session.update(job_id=job_id, artists=[])  # the previous search's list is dropped
        for old_id in list(jobs)[:-10]:
            if old_id not in stop_events:
                jobs.pop(old_id, None)
        state = copy.deepcopy(jobs[job_id])
    threading.Thread(target=run_search, args=(job_id, body, stop), daemon=True, name=f"search-{job_id[:8]}").start()
    return state


@app.get("/api/search/{job_id}")
def search_status(job_id: str):
    with jobs_lock:
        if job_id not in jobs:
            raise HTTPException(404, "검색 작업을 찾을 수 없습니다.")
        return copy.deepcopy(jobs[job_id])


@app.get("/api/search/{job_id}/more")
def more_results(job_id: str, offset: int = Query(0, ge=0)):
    """더 보기: the next slice of the finished search's list. Never searches Danbooru again,
    never looks post counts up and never touches the seen history."""
    with jobs_lock:
        job = jobs.get(job_id)
        if job is None or results_session["job_id"] != job_id:
            raise HTTPException(410, "이전 검색 결과는 새 검색을 시작하면서 지워졌습니다. 다시 검색해 주세요.")
        if job_id in stop_events:
            raise HTTPException(409, "검색이 아직 끝나지 않았습니다.")
        ranked = results_session["artists"]
        end = offset + result_page_size(job)
        return {"artists": copy.deepcopy(ranked[offset:end]), "offset": offset,
                "next_offset": min(end, len(ranked)), "total": len(ranked)}


@app.post("/api/search/{job_id}/stop")
def stop_search(job_id: str):
    with jobs_lock:
        if job_id not in jobs:
            raise HTTPException(404, "검색 작업을 찾을 수 없습니다.")
        jobs[job_id]["stop_requested"] = True
        if job_id in stop_events:
            stop_events[job_id].set()
        return copy.deepcopy(jobs[job_id])


@app.delete("/api/history")
def clear_history():
    """Finder's own seen_artists.json only; Artist Lab is never contacted."""
    try:
        storage.clear_seen()
    except OSError as exc:
        raise HTTPException(500, "수집 기록을 초기화하지 못했습니다.") from exc
    return {"seen_count": 0}


@app.delete("/api/post-count-cache")
def clear_post_count_cache():
    """작품 수 캐시 초기화: artist_post_count_cache.json only. Settings, the seen history and the
    current results stay."""
    with jobs_lock:
        if stop_events:
            raise HTTPException(409, "검색 중에는 작품 수 캐시를 초기화할 수 없습니다. 검색이 끝난 뒤 다시 시도해 주세요.")
        try:
            storage.clear_post_counts()
        except OSError as exc:
            log.warning("Could not clear artist_post_count_cache.json: %s", exc.__class__.__name__)
            raise HTTPException(500, f"작품 수 캐시를 초기화하지 못했습니다: {exc.strerror or exc}") from exc
    return {"post_count_cache_count": 0}


@app.get("/api/artist-lab/status")
def artist_lab_status(url: str = DEFAULT_ARTIST_LAB_URL):
    try:
        with ArtistLabClient(url) as lab:
            return lab.status()
    except ArtistLabError as exc:
        return {"connected": False, "integration_ready": False, "message": str(exc)}


@app.post("/api/artist-lab/send")
def artist_lab_send(body: LabSendRequest):
    names = clean_artist_names(body.artists)
    try:
        with ArtistLabClient(body.artist_lab_url) as lab:
            return lab.send_direct_input(names)
    except ArtistLabError as exc:
        raise HTTPException(502, str(exc)) from exc


app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")


@app.middleware("http")
async def local_security_headers(request, call_next):
    response = await call_next(request)
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; connect-src 'self'; img-src 'self' data:; "
        "script-src 'self'; style-src 'self'; object-src 'none'; frame-src 'none'; "
        "base-uri 'none'; form-action 'none'"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/")
def home():
    return FileResponse(ROOT / "static" / "index.html")
