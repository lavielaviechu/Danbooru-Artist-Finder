"""Danbooru 전체 등록 작품 수 (tag post_count) with a local cache.

Cache hits never touch the network. Misses are asked for in batches of
POST_COUNT_BATCH_SIZE names per /tags.json request, one request at a time with the page
delay in between. A name Danbooru does not return stays unknown (never 0).
"""
from __future__ import annotations

import logging
import time
from typing import Callable

from .config import PAGE_DELAY_SECONDS, POST_COUNT_BATCH_SIZE, POST_COUNT_CACHE_TTL_SECONDS
from .danbooru import DanbooruError, SearchStopped

log = logging.getLogger("artist_finder")


class PostCountLookup:
    def __init__(self, client, storage, *, sleep: Callable[[float], None] = time.sleep, delay: float = PAGE_DELAY_SECONDS,
                 ttl: float = POST_COUNT_CACHE_TTL_SECONDS, batch_size: int = POST_COUNT_BATCH_SIZE,
                 clock: Callable[[], float] = time.time):
        self.client = client
        self.storage = storage
        self.sleep = sleep
        self.delay = delay
        self.ttl = ttl
        self.batch_size = batch_size
        self.clock = clock
        self._cache = storage.load_post_counts()
        self.requests = 0
        self.error = ""  # set when a batch failed after all retries; later batches are skipped

    def cached(self, names: list[str]) -> dict[str, int]:
        """Fresh cache entries only (no network)."""
        now = self.clock()
        result = {}
        for name in names:
            entry = self._cache.get(name)
            if entry and now - entry["fetched_at"] < self.ttl:
                result[name] = entry["post_count"]
        return result

    def lookup(self, names: list[str], *, stop_requested: Callable[[], bool] = lambda: False,
               progress: Callable[[dict], None] = lambda _: None) -> dict[str, int]:
        """post_count per name; unknown names are missing from the result. Raises
        SearchStopped when the user stops; what was fetched so far is already cached."""
        result = self.cached(names)
        # Danbooru tag names cannot contain commas; such a name could not be sent in name_comma.
        missing = [name for name in dict.fromkeys(names) if name not in result and "," not in name]
        if not missing or self.error:
            return result
        batches = [missing[i:i + self.batch_size] for i in range(0, len(missing), self.batch_size)]
        for index, batch in enumerate(batches):
            if stop_requested():
                raise SearchStopped()
            progress({"phase": "counting", "count_done": index * self.batch_size, "count_total": len(missing),
                      "count_batch": index + 1, "count_batches": len(batches)})
            if index:
                self.sleep(self.delay)
                if stop_requested():
                    raise SearchStopped()
            self.requests += 1
            try:
                found = self.client.fetch_post_counts(batch, progress=progress)
            except DanbooruError as exc:
                self.error = str(exc)
                log.warning("Post count lookup failed (%s); %s names stay unknown", exc.kind, len(missing) - index * self.batch_size)
                break
            folded = {name.casefold(): count for name, count in found.items()}
            now = self.clock()
            for name in batch:
                count = found.get(name, folded.get(name.casefold()))
                if count is not None:
                    result[name] = count
                    self._cache[name] = {"post_count": count, "fetched_at": now}
            self._save()
        else:
            progress({"phase": "counting", "count_done": len(missing), "count_total": len(missing),
                      "count_batch": len(batches), "count_batches": len(batches)})
        return result

    def _save(self) -> None:
        try:
            self.storage.save_post_counts(self._cache)
        except OSError:
            log.warning("artist_post_count_cache.json could not be written")
