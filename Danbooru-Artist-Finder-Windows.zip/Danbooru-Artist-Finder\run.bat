@echo off
setlocal
cd /d "%~dp0"
title Danbooru Artist Finder

set "PORTABLE_PY=%~dp0python\python.exe"
set "PORTABLE_PYW=%~dp0python\pythonw.exe"
if not exist "%PORTABLE_PY%" goto missing_runtime
if not exist "%PORTABLE_PYW%" goto missing_runtime

set "PYTHONHOME="
set "PYTHONPATH="
set "PYTHONNOUSERSITE=1"
set "PYTHONDONTWRITEBYTECODE=1"

rem Check the bundled components first so a problem stays visible in this console.
"%PORTABLE_PY%" -X utf8 app.py --check
if errorlevel 1 (
  echo.
  echo Danbooru Artist Finder cannot start. See the messages above and logs\app.log.
  pause
  exit /b 1
)

rem The app window runs without a console. Startup errors are shown in a dialog and logs\app.log.
start "" "%PORTABLE_PYW%" -X utf8 app.py
exit /b 0

:missing_runtime
echo [ERROR] The portable Python runtime is missing.
echo.
echo Expected files:
echo   %PORTABLE_PY%
echo   %PORTABLE_PYW%
echo.
echo Please extract the complete Danbooru-Artist-Finder-Windows ZIP again.
pause
exit /b 1
