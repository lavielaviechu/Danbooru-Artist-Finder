"""Danbooru Artist Finder desktop launcher.

run.bat -> `python.exe app.py --check` (console: dependency check) -> `pythonw.exe app.py`
-> local backend on 127.0.0.1 (backend/server.py) + one pywebview window. No browser is
ever opened. Closing the window stops the backend and ends the process.

Startup order: backend thread -> bounded HTTP readiness (GET / and /static/app.js must
return 200) -> only then the window is created -> bounded load guard (WebView2 init
failure, navigation to a non-Finder page, or no load event) closes the window and shows
an error dialog instead of leaving a blank window. Details go to logs/app.log.

Only the standard library is imported at module level so that a missing or broken
dependency is still logged and reported instead of the console vanishing.
"""
from __future__ import annotations

import json
import logging
import os
import socket
import sys
import threading
import time
import traceback
from logging.handlers import RotatingFileHandler
from pathlib import Path

from backend.config import APP_NAME, BIND_HOST, DEFAULT_PORT, PORT_SCAN_LIMIT

ROOT = Path(__file__).resolve().parent
LOG_PATH = ROOT / "logs" / "app.log"
REQUIRED_MODULES = ("fastapi", "uvicorn", "httpx", "pydantic", "webview", "clr")
WEBVIEW2_CLIENT_KEY = r"Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
# Backend must answer HTTP 200 within this before any window exists.
READY_TIMEOUT_SECONDS = 15.0
# WebView2 cold start (fresh private profile) took about 5-13 s on the development PC.
LOAD_TIMEOUT_SECONDS = 45.0
PAGE_CHECK_TIMEOUT_SECONDS = 10.0
READY_MARKER = f"<title>{APP_NAME}</title>".encode("utf-8")
REQUIRED_PAGE_IDS = ("query", "collectBtn", "resultsPanel", "sendLabBtn", "labState")
log = logging.getLogger("artist_finder")


class StartupError(RuntimeError):
    pass


def setup_logging() -> None:
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    handlers: list[logging.Handler] = [RotatingFileHandler(LOG_PATH, maxBytes=2_000_000, backupCount=2, encoding="utf-8")]
    if sys.stderr is not None:  # pythonw has no console
        handlers.append(logging.StreamHandler())
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s", handlers=handlers)


def show_error_dialog(message: str) -> None:
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, message, f"{APP_NAME} 실행 오류", 0x10)
    except Exception:
        pass


def webview2_installed() -> bool:
    try:
        import winreg
    except ImportError:
        return False
    for hive, prefix in ((winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node"), (winreg.HKEY_LOCAL_MACHINE, "SOFTWARE"),
                         (winreg.HKEY_CURRENT_USER, "SOFTWARE")):
        try:
            with winreg.OpenKey(hive, rf"{prefix}\{WEBVIEW2_CLIENT_KEY}") as key:
                version, _ = winreg.QueryValueEx(key, "pv")
                if version and version != "0.0.0.0":
                    return True
        except OSError:
            continue
    return False


def check_runtime() -> list[str]:
    """Problems that would stop the window from opening; empty when ready."""
    problems = []
    longest = max((len(str(path)) for path in (ROOT / "python").rglob("*")), default=0)
    if longest > 259:  # Windows MAX_PATH: bundled DLLs fail to load from a too-deep folder
        problems.append(f"폴더 경로가 너무 깁니다 (가장 긴 파일 경로 {longest}자). "
                        r"C:\Tools 처럼 짧은 경로에 ZIP을 풀어 주세요.")
    # Files extracted from a downloaded ZIP carry Mark of the Web; .NET Framework then refuses
    # to load Python.Runtime.dll / WebView2 assemblies unless the host .exe.config enables
    # loadFromRemoteSources (the cause of "Failed to resolve Python.Runtime.Loader").
    for exe in ("python.exe", "pythonw.exe"):
        config = ROOT / "python" / f"{exe}.config"
        if "loadFromRemoteSources" not in (config.read_text(encoding="utf-8", errors="replace") if config.is_file() else ""):
            problems.append(f"'python\\{exe}.config' 파일이 없거나 손상되었습니다. ZIP을 다시 완전히 풀어 주세요.")
    for module in REQUIRED_MODULES:
        try:
            __import__(module)
        except Exception as exc:
            hint = " (.NET Framework 구성 요소를 불러오지 못했습니다. ZIP을 다시 완전히 풀어 주세요.)" if module == "clr" else ""
            problems.append(f"구성 요소 '{module}'을(를) 불러오지 못했습니다: {exc.__class__.__name__}: {exc}{hint}")
    if not webview2_installed():
        problems.append("Microsoft Edge WebView2 Runtime을 찾지 못했습니다. Windows 업데이트 또는 Microsoft 배포본으로 설치해 주세요.")
    for folder in ("static", "backend"):
        if not (ROOT / folder).is_dir():
            problems.append(f"'{folder}' 폴더가 없습니다. ZIP을 다시 완전히 풀어 주세요.")
    return problems


def bind_loopback(start: int = DEFAULT_PORT, count: int = PORT_SCAN_LIMIT) -> socket.socket:
    """Bind the backend socket here (127.0.0.1 only) and hand it to uvicorn, so no other
    program can take the port between the check and the server start."""
    for port in range(start, start + count + 1):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.bind((BIND_HOST, port))
        except OSError:
            sock.close()
            continue
        return sock
    raise StartupError(f"사용 가능한 로컬 포트를 찾지 못했습니다 ({start}~{start + count}).")


class DesktopRuntime:
    """uvicorn on a background thread; stop() ends it before the process exits."""

    def __init__(self, sock: socket.socket, asgi_app) -> None:
        import uvicorn
        self.sock = sock
        self.port = sock.getsockname()[1]
        self.server = uvicorn.Server(uvicorn.Config(asgi_app, log_config=None, access_log=False))
        self.thread = threading.Thread(target=self.server.run, kwargs={"sockets": [sock]}, name="finder-backend", daemon=True)

    def start(self, timeout: float = 10.0) -> None:
        self.thread.start()
        deadline = time.monotonic() + timeout
        while not self.server.started:
            if not self.thread.is_alive():
                raise StartupError("로컬 백엔드를 시작하지 못했습니다. logs\\app.log를 확인해 주세요.")
            if time.monotonic() >= deadline:
                raise StartupError("로컬 백엔드 시작 시간이 초과되었습니다.")
            time.sleep(0.05)

    def stop(self, timeout: float = 5.0) -> None:
        self.server.should_exit = True
        if self.thread.is_alive():
            self.thread.join(timeout)
        if self.thread.is_alive():
            self.server.force_exit = True
            self.thread.join(2.0)
        self.sock.close()


def wait_until_ready(base_url: str, runtime: DesktopRuntime | None = None, timeout: float = READY_TIMEOUT_SECONDS,
                     interval: float = 0.2) -> dict:
    """Bounded readiness check before any window exists: Finder's index (GET /) and its
    script (GET /static/app.js) must both return HTTP 200. Raises StartupError on timeout."""
    import urllib.error
    import urllib.request

    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # loopback: never via a proxy
    started = time.monotonic()
    deadline = started + timeout
    attempts, last = 0, "응답 없음"
    while True:
        attempts += 1
        if runtime is not None and not runtime.thread.is_alive():
            raise StartupError("로컬 백엔드가 준비 중에 종료되었습니다. 프로그램 창을 열지 않았습니다.")
        try:
            with opener.open(base_url, timeout=2) as response:
                status, body = response.status, response.read()
            if status == 200 and READY_MARKER in body:
                with opener.open(base_url + "static/app.js", timeout=2) as script:
                    if script.status == 200:
                        return {"attempts": attempts, "seconds": round(time.monotonic() - started, 2)}
                    last = f"app.js HTTP {script.status}"
            else:
                last = f"HTTP {status}" if status != 200 else "Finder 화면이 아닌 응답"
        except urllib.error.HTTPError as exc:
            last = f"HTTP {exc.code}"
        except (urllib.error.URLError, OSError) as exc:
            reason = getattr(exc, "reason", exc)
            last = f"{reason.__class__.__name__}: {reason}" if isinstance(reason, BaseException) else str(reason)
        if time.monotonic() >= deadline:
            raise StartupError(f"로컬 백엔드가 {timeout:g}초 안에 준비되지 않았습니다 (시도 {attempts}회, 마지막 결과: {last}). "
                               "프로그램 창을 열지 않았습니다.")
        time.sleep(interval)


class WebViewInitWatch(logging.Handler):
    """pywebview logs a failed WebView2 initialization and returns, leaving a blank window
    that never fires `loaded`. This handler turns that log record into a startup failure."""

    def __init__(self) -> None:
        super().__init__(logging.ERROR)
        self.failed = threading.Event()
        self.detail = ""

    def emit(self, record: logging.LogRecord) -> None:
        message = record.getMessage()
        if "WebView2 initialization failed" in message:
            lines = [line.strip() for line in message.splitlines() if line.strip()]
            self.detail = (lines[1] if len(lines) > 1 else lines[0])[:300]
            self.failed.set()


def read_page_state(window, timeout: float = PAGE_CHECK_TIMEOUT_SECONDS) -> dict | None:
    """window.evaluate_js waits without a limit; run it on a helper thread with a timeout."""
    ids = json.dumps(list(REQUIRED_PAGE_IDS))
    script = (f"(()=>({{title:document.title,href:location.href,ready:document.readyState,"
              f"missing:{ids}.filter(id=>!document.getElementById(id))}}))()")
    result: dict = {}

    def run() -> None:
        try:
            result["state"] = window.evaluate_js(script)
        except Exception as exc:
            result["error"] = f"{exc.__class__.__name__}: {exc}"

    worker = threading.Thread(target=run, name="finder-page-check", daemon=True)
    worker.start()
    worker.join(timeout)
    if "error" in result:
        log.warning("Page check failed: %s", result["error"])
    state = result.get("state")
    return state if isinstance(state, dict) else None


CLOSED_BY_USER = "closed"


def guard_window_load(window, url: str, init_watch: WebViewInitWatch, timeout: float = LOAD_TIMEOUT_SECONDS) -> str | None:
    """Wait (bounded) until Finder's own page is loaded in the window. Returns None on success,
    CLOSED_BY_USER if the user closed the window first, otherwise a failure message."""
    started = time.monotonic()
    deadline = started + timeout
    while not window.events.loaded.is_set():
        if init_watch.failed.is_set():
            return f"WebView2 초기화에 실패했습니다 ({init_watch.detail})."
        if window.events.closed.is_set():
            return CLOSED_BY_USER
        if time.monotonic() >= deadline:
            return f"프로그램 화면이 {timeout:g}초 안에 열리지 않았습니다."
        window.events.loaded.wait(0.25)
    if init_watch.failed.is_set():
        return f"WebView2 초기화에 실패했습니다 ({init_watch.detail})."
    state = read_page_state(window)
    if not state:
        return "프로그램 화면 상태를 확인하지 못했습니다."
    if state.get("title") != APP_NAME or not str(state.get("href", "")).startswith(url) or state.get("missing"):
        missing = ", ".join(state.get("missing") or []) or "없음"
        return f"Finder 화면 대신 다른 페이지가 열렸습니다 (제목 확인 {state.get('title') == APP_NAME}, 누락 요소 {missing})."
    log.info("Finder page loaded in the window (%.1fs)", time.monotonic() - started)
    return None


class FinderBridge:
    """Exposed to the page as window.pywebview.api (public methods only)."""

    def __init__(self, save_dialog_type=None) -> None:
        self._window = None
        self._save_dialog_type = save_dialog_type

    def save_text(self, names: list, query: str = "") -> dict:
        from backend.core import artists_to_text, txt_filename
        from backend.server import clean_artist_names

        cleaned = clean_artist_names([str(name) for name in (names or [])])
        if not cleaned:
            return {"saved": False, "error": "저장할 작가가 없습니다."}
        try:
            chosen = self._window.create_file_dialog(
                self._save_dialog_type, save_filename=txt_filename(str(query or "")), file_types=("Text file (*.txt)",),
            )
        except Exception as exc:
            log.exception("Save dialog failed")
            return {"saved": False, "error": f"저장 창을 열지 못했습니다: {exc}"}
        if not chosen:
            return {"saved": False, "cancelled": True}
        path = Path(chosen if isinstance(chosen, str) else chosen[0])
        try:
            path.write_text(artists_to_text(cleaned), encoding="utf-8")
        except OSError as exc:
            log.warning("TXT save failed: %s", exc.__class__.__name__)
            return {"saved": False, "error": f"TXT 저장 실패: {exc.strerror or exc}"}
        return {"saved": True, "file": path.name, "count": len(cleaned)}


def run_smoke_check(window, close_ms: int, report_path: str) -> None:
    """DAF_SMOKE_CLOSE_MS: verify the real window, write a report, then close it."""
    report: dict = {"ok": False}
    try:
        report["loaded"] = window.events.loaded.wait(30)
        try:
            import ctypes
            report["native_window_found"] = bool(ctypes.windll.user32.FindWindowW(None, APP_NAME))
        except Exception as exc:
            report["native_window_error"] = str(exc)
        if report["loaded"]:
            time.sleep(1.0)
            report["ui"] = window.evaluate_js(
                "(()=>{const ids=['query','targetCount','pageScope','sfwOnly','sortMode','collectBtn','stopBtn',"
                "'resultsPanel','resultBody','sendLabBtn','labState','copySelectedBtn','saveTxtBtn','clearHistoryBtn','clearCountCacheBtn','moreBtn'];"
                "return {title:document.title,scope:document.querySelector('#pageScope')?.value,"
                "scopes:[...document.querySelectorAll('#pageScope option')].map(o=>o.textContent),"
                "sorts:[...document.querySelectorAll('#sortMode option')].map(o=>o.textContent),"
                "sfw:document.querySelector('#sfwOnly')?.checked,target:document.querySelector('#targetCount')?.value,"
                "missing:ids.filter(id=>!document.getElementById(id)),bridge:!!(window.pywebview&&window.pywebview.api),"
                "lab:document.querySelector('#labState')?.textContent,href:location.href}})()"
            )
            ui = report["ui"] or {}
            report["ok"] = ui.get("title") == APP_NAME and not ui.get("missing") and report.get("native_window_found", False)
        time.sleep(close_ms / 1000)
    except Exception as exc:
        report["error"] = f"{exc.__class__.__name__}: {exc}"
    finally:
        if report_path:
            Path(report_path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        log.info("Desktop smoke check: %s", report)
        window.destroy()


def run_desktop() -> int:
    try:
        import webview
        from backend import server
    except Exception as exc:
        raise StartupError(f"실행 구성 요소를 불러오지 못했습니다 ({exc.__class__.__name__}: {exc}). ZIP을 다시 완전히 풀어 주세요.") from exc

    runtime = DesktopRuntime(bind_loopback(), server.app)
    init_watch = WebViewInitWatch()
    pywebview_log = logging.getLogger("pywebview")
    try:
        runtime.start()
        url = f"http://{BIND_HOST}:{runtime.port}/"
        log.info("Backend listening on %s", url)
        ready = wait_until_ready(url, runtime, timeout=READY_TIMEOUT_SECONDS)
        log.info("Backend ready: HTTP 200 after %d attempt(s), %.2fs", ready["attempts"], ready["seconds"])

        webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = False
        bridge = FinderBridge(webview.FileDialog.SAVE)
        window = webview.create_window(
            APP_NAME, url=url, js_api=bridge, width=820, height=780, min_size=(640, 560),
            background_color="#14161d", text_select=True,
        )
        bridge._window = window
        smoke_ms = int(os.environ.get("DAF_SMOKE_CLOSE_MS", "0") or 0)
        smoke_report = os.environ.get("DAF_SMOKE_REPORT", "")
        outcome: dict = {"failure": None}

        def after_start() -> None:
            failure = guard_window_load(window, url, init_watch, timeout=LOAD_TIMEOUT_SECONDS)
            if failure == CLOSED_BY_USER:
                return
            if failure:
                outcome["failure"] = failure
                log.error("Window load failed: %s", failure)
                if smoke_ms > 0 and smoke_report:
                    Path(smoke_report).write_text(json.dumps({"ok": False, "startup_error": failure}, ensure_ascii=False,
                                                             indent=2), encoding="utf-8")
                window.destroy()
                return
            if smoke_ms > 0:
                run_smoke_check(window, smoke_ms, smoke_report)

        pywebview_log.addHandler(init_watch)
        try:
            webview.start(after_start, gui="edgechromium", debug=False, private_mode=True)
        except Exception as exc:
            raise StartupError(f"프로그램 창을 만들지 못했습니다 ({exc.__class__.__name__}: {exc}). "
                               "Microsoft Edge WebView2 Runtime 설치 여부를 확인하고, 계속되면 ZIP을 다시 완전히 풀어 주세요.") from exc
        log.info("Window closed")
        if outcome["failure"]:
            raise StartupError(f"{outcome['failure']} 프로그램 창을 닫았습니다. "
                               "Microsoft Edge WebView2 Runtime 설치 상태를 확인하고 다시 실행해 주세요.")
    finally:
        pywebview_log.removeHandler(init_watch)
        server.stop_all_jobs()
        runtime.stop()
        log.info("Backend stopped")
    return 0


def main(argv: list[str]) -> int:
    setup_logging()
    if "--check" in argv:
        problems = check_runtime()
        for problem in problems:
            print(f"[ERROR] {problem}")
            log.error("Startup check: %s", problem)
        if not problems:
            print(f"{APP_NAME}: 실행 준비 완료")
        return 1 if problems else 0
    try:
        return run_desktop()
    except Exception as exc:
        log.exception("Desktop startup failed")
        detail = f"{APP_NAME}을(를) 시작하지 못했습니다.\n\n{exc}\n\n자세한 내용: logs\\app.log"
        if sys.stderr is not None:
            print(detail, file=sys.stderr)
            traceback.print_exc()
        if not os.environ.get("DAF_SMOKE_CLOSE_MS"):
            show_error_dialog(detail)
        return 1


if __name__ == "__main__":
    code = main(sys.argv[1:])
    logging.shutdown()
    for stream in (sys.stdout, sys.stderr):
        if stream is not None:
            stream.flush()
    # Hard exit: no WebView2/pythonnet or search thread can keep the process alive.
    os._exit(code)
