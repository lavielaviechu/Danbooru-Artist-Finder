const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const fmt = n => Number(n || 0).toLocaleString('ko-KR');
const SORT_HINT = {
  frequency: '선택한 탐색 범위를 끝까지 조사한 뒤 빈도를 계산합니다.',
  post_count: '선택한 탐색 범위를 끝까지 조사한 뒤 후보 작가의 Danbooru 전체 등록 작품 수를 확인해 많은 순으로 정렬합니다.',
  first_seen: '목표 작가 수를 채우면 현재 페이지까지 처리하고 일찍 끝냅니다.',
  random: '선택한 탐색 범위를 끝까지 조사한 뒤 전체 후보에서 무작위로 고릅니다.',
};
const SORT_LABEL = {frequency: '검색 내 등장 빈도순', post_count: '전체 등록 작품 수순', first_seen: '처음 발견된 순', random: '랜덤'};
// Finder LabSendRequest and Artist Lab FinderDirectInputRequest both accept at most 500 names, and
// Artist Lab replaces its Direct Input list on every POST, so a larger selection is not split.
const LAB_SEND_LIMIT = 500;
let jobId = null, pollTimer = null, results = [], lastJob = null;
let labStatus = {connected: false, integration_ready: false, message: '연결 안 됨'};

function esc(v) { return String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function toast(message, error = false) {
  const node = $('#toast'); node.textContent = message; node.className = `toast show${error ? ' error' : ''}`;
  clearTimeout(node._timer); node._timer = setTimeout(() => node.className = 'toast', 3800);
}
async function api(url, options = {}) {
  const response = await fetch(url, {...options, headers: {'Content-Type': 'application/json', ...(options.headers || {})}});
  if (!response.ok) {
    let message = `요청 실패 (${response.status})`;
    try { const data = await response.json(); message = data.detail || message; } catch {}
    throw new Error(Array.isArray(message) ? message.map(x => x.msg).join(', ') : message);
  }
  return response.status === 204 ? null : response.json();
}

/* Settings: restored on start, saved on change. A search only ever starts from a button. */
function settings() {
  return {target_count: Number($('#targetCount').value), page_scope: $('#pageScope').value, sfw_only: $('#sfwOnly').checked,
    sort_mode: $('#sortMode').value, exclude_seen: $('#excludeSeen').checked, exclude_artist_pool: $('#excludePool').checked,
    artist_lab_url: $('#labUrl').value.trim(), min_post_count_enabled: $('#minPostEnabled').checked,
    min_post_count: Math.max(0, Math.floor(Number($('#minPostCount').value) || 0))};
}
function fillSettings(s) {
  $('#targetCount').value = s.target_count; $('#pageScope').value = s.page_scope; $('#sfwOnly').checked = s.sfw_only;
  $('#sortMode').value = s.sort_mode; $('#excludeSeen').checked = s.exclude_seen; $('#excludePool').checked = s.exclude_artist_pool;
  $('#labUrl').value = s.artist_lab_url; $('#minPostEnabled').checked = s.min_post_count_enabled; $('#minPostCount').value = s.min_post_count;
  updateHints();
}
function saveSettingsSoon() {
  clearTimeout(saveSettingsSoon.timer);
  saveSettingsSoon.timer = setTimeout(() => api('/api/settings', {method: 'PUT', body: JSON.stringify(settings())}).catch(e => toast(e.message, true)), 400);
}
function updateHints() {
  $('#scopeHint').classList.toggle('hidden', $('#pageScope').value !== 'all');
  $('#sortHint').textContent = SORT_HINT[$('#sortMode').value] || '';
  $('#minPostCount').disabled = !$('#minPostEnabled').checked;
}
function setHistoryCount(n) { $('#historyCount').textContent = `(${fmt(n)}명)`; }
function setCountCacheCount(n) { $('#countCacheCount').textContent = `(${fmt(n)}명)`; }
function refreshDataCounts() {
  api('/api/bootstrap').then(data => { setHistoryCount(data.seen_count); setCountCacheCount(data.post_count_cache_count); }).catch(() => {});
}
/* Small confirm dialog with 취소 / 초기화 buttons; resolves true only on 초기화. */
function confirmReset(message) {
  const dialog = $('#confirmDialog');
  $('#confirmText').textContent = message;
  return new Promise(resolve => {
    const done = ok => { dialog.close(); $('#confirmOkBtn').onclick = $('#confirmCancelBtn').onclick = dialog.oncancel = null; resolve(ok); };
    $('#confirmOkBtn').onclick = () => done(true);
    $('#confirmCancelBtn').onclick = () => done(false);
    dialog.oncancel = e => { e.preventDefault(); done(false); };
    dialog.showModal();
  });
}

/* Artist Lab: optional. Finder works the same without it. */
function applyLabStatus(status) {
  labStatus = status;
  const node = $('#labState');
  node.classList.toggle('off', !status.connected); node.classList.toggle('warn', status.connected && !status.integration_ready);
  $('#labStateText').textContent = status.connected ? (status.integration_ready ? '● 연결됨' : '● 업데이트 필요') : '○ 연결 안 됨';
  node.title = status.message; $('#labDetail').textContent = status.message;
  const pool = $('#excludePool');
  pool.disabled = !status.integration_ready;
  $('#excludePoolLabel').classList.toggle('disabled', pool.disabled);
}
async function checkLab(silent = false) {
  try {
    const status = await api(`/api/artist-lab/status?url=${encodeURIComponent($('#labUrl').value.trim())}`);
    applyLabStatus(status); if (!silent) toast(`Artist Lab: ${status.message}`, !status.integration_ready);
  } catch (e) { if (!silent) toast(e.message, true); }
}

/* Search */
async function collect() {
  if (jobId) return;
  const query = $('#query').value.trim();
  if (!query) { toast('검색어를 입력해 주세요.', true); $('#query').focus(); return; }
  const body = {...settings(), query};
  body.exclude_artist_pool = body.exclude_artist_pool && !$('#excludePool').disabled;
  try {
    await api('/api/settings', {method: 'PUT', body: JSON.stringify(settings())});
    const job = await api('/api/search', {method: 'POST', body: JSON.stringify(body)});
    jobId = job.job_id; setRunning(true);
    $('#progressPanel').classList.remove('hidden');
    renderProgress(job); schedulePoll();
  } catch (e) { toast(e.message, true); }
}
function setRunning(running) {
  $('#collectBtn').disabled = running; $('#againBtn').disabled = running; $('#moreBtn').disabled = running; $('#stopBtn').disabled = !running;
  $('#stopBtn').textContent = '중지';
}
function schedulePoll() { clearTimeout(pollTimer); pollTimer = setTimeout(poll, 500); }
async function poll() {
  if (!jobId) return;
  try {
    const job = await api(`/api/search/${jobId}`);
    renderProgress(job);
    if (['completed', 'stopped', 'error'].includes(job.status)) { finish(job); return; }
  } catch (e) { toast(e.message, true); }
  schedulePoll();
}
function renderProgress(job) {
  const all = job.page_limit == null, done = ['completed', 'stopped', 'error'].includes(job.status);
  const counting = job.phase === 'counting' && !done;
  $('#progressTitle').textContent = done ? '탐색 종료' : job.stop_requested ? '중지하는 중...'
    : counting ? `작가 작품 수 확인 중... ${fmt(job.count_done)} / ${fmt(job.count_total)}` : '검색 중...';
  const connection = job.phase === 'retrying' ? `재시도 ${job.retry}/${job.max_retries}`
    : ['starting', 'connecting'].includes(job.phase) ? 'Danbooru 연결 중...' : done ? ''
    : counting ? `${job.count_batch} / ${job.count_batches} 묶음` : '연결 성공';
  $('#connectionText').textContent = connection;
  $('#connectionText').classList.toggle('warn', job.phase === 'retrying');
  const state = $('#danbooruState');
  state.className = `status ${job.phase === 'retrying' ? 'warn' : job.status === 'error' && job.error_kind ? 'off' : done ? 'idle' : ''}`;
  state.title = connection || 'Danbooru';
  const pageText = all ? `${fmt(job.pages)} 페이지 탐색` : `${fmt(job.pages)} / ${job.page_limit} 페이지`;
  $('#progressStats').textContent = `${pageText} · ${fmt(job.posts)} posts 확인 · ${fmt(job.artists)} artist 발견`;
  const meter = $('#progressBar');
  meter.classList.toggle('indeterminate', all && !done);
  meter.style.width = all ? '100%' : `${Math.min(100, (job.pages || 0) / job.page_limit * 100)}%`;
  $('#queryUsed').textContent = `실제 query: ${job.query_used || ''}`;
}
function finish(job) {
  clearTimeout(pollTimer); jobId = null; lastJob = job; setRunning(false);
  results = [];
  renderResults(job);
  appendRows(job.artists_data || []);
  if (job.warning) toast(job.warning, true);
  else if (job.status === 'error') toast(job.error, true);
  else toast(job.status === 'stopped' ? '사용자 중지 · 부분 결과를 표시합니다.' : `${results.length}명의 작가를 정리했습니다.`);
  refreshDataCounts();
}
function renderResults(job) {
  $('#resultsPanel').classList.remove('hidden'); $('#labMessage').classList.add('hidden');
  const total = job.total_results ?? (job.artists_data || []).length, found = job.found ?? total;
  $('#resultSummary').textContent = `${fmt(total)}명 발견 · ${SORT_LABEL[job.sort_mode] || ''}`
    + (found > total ? ` (후보 ${fmt(found)}명 중 조건 통과)` : '');
  let status;
  if (job.status === 'stopped') status = '사용자 중지 · 부분 결과';
  else if (job.status === 'error') status = `${job.error}${total ? ' · 지금까지의 부분 결과' : ''}`;
  else status = `완료 · ${job.stop_reason}`;
  $('#resultStatus').textContent = `${status} · ${fmt(job.pages)} 페이지 · ${fmt(job.posts)} posts 확인`;
  const notes = [];
  if (total < job.target_count) notes.push(job.min_post_count > 0 && job.filtered_out
    ? `${fmt(total)}명 발견 · 최소 작품 수 조건을 만족하는 작가가 요청 수보다 적습니다.`
    : `${fmt(total)}명 발견 · 요청한 ${fmt(job.target_count)}명보다 적은 결과입니다.`);
  if (job.min_post_count > 0) notes.push(`등록 작품 ${fmt(job.min_post_count)}개 미만 ${fmt(job.filtered_out)}명 제외.`);
  if (job.count_unknown) notes.push(`작품 수 확인 실패 ${fmt(job.count_unknown)}명은 "전체 ?"로 표시${job.min_post_count > 0 ? '하고 필터에서 제외하지 않았습니다' : '합니다'}.`);
  if (job.count_error) notes.push(job.count_error);
  if (job.stop_reason === 'Danbooru 페이지 한도 도달') notes.push('Danbooru는 order: 검색에서 1000페이지까지만 제공합니다.');
  $('#resultNote').textContent = notes.join(' ');
  $('#resultNote').classList.toggle('hidden', !notes.length);
  $('#resultBody').innerHTML = total ? '' : '<tr><td colspan="4" class="muted empty">수집된 작가가 없습니다.</td></tr>';
}
/* Rows are added page by page (처음 목표 작가 수, then 더 보기); earlier rows keep their checks. */
function totalCell(item) {
  if (!lastJob.counts_used) return '<td class="count muted" title="이 검색에서는 작품 수를 조회하지 않았습니다 (전체 등록 작품 수 정렬·최소 작품 수 필터에서만 조회)">-</td>';
  return item.post_count == null ? '<td class="count unknown" title="작품 수 확인 실패">?</td>'
    : `<td class="count" title="Danbooru 전체 등록 post 수">${fmt(item.post_count)}</td>`;
}
function appendRows(items) {
  results.push(...items);
  $('#resultBody').insertAdjacentHTML('beforeend', items.map(item => `<tr><td class="sel"><input type="checkbox" checked data-name="${esc(item.name)}" aria-label="${esc(item.name)} 선택"></td>`
    + `<td class="name">${esc(item.name)}</td><td class="count" title="현재 Finder 탐색 범위에서 발견된 post 수">${fmt(item.count)}</td>`
    + totalCell(item) + '</tr>').join(''));
  updateShown(); updateSelectedCount();
}
function updateShown() {
  const total = lastJob?.total_results ?? results.length;
  $('#shownCount').textContent = total ? `${fmt(results.length)} / ${fmt(total)}명 표시` : '';
  $('#moreBtn').classList.toggle('hidden', results.length >= total);
}
/* 더 보기: the next slice of this search's list from the backend. No new Danbooru search. */
async function showMore() {
  if (!lastJob || jobId) return;
  $('#moreBtn').disabled = true;
  try {
    const page = await api(`/api/search/${lastJob.job_id}/more?offset=${results.length}`);
    appendRows(page.artists);
  } catch (e) { toast(e.message, true); }
  finally { $('#moreBtn').disabled = false; }
}
async function stop() {
  if (!jobId) return;
  $('#stopBtn').disabled = true; $('#stopBtn').textContent = '중지 중...';
  try { renderProgress(await api(`/api/search/${jobId}/stop`, {method: 'POST'})); }
  catch (e) { toast(e.message, true); $('#stopBtn').disabled = false; $('#stopBtn').textContent = '중지'; }
}

/* Results */
function selectedNames() { return $$('#resultBody input:checked').map(node => node.dataset.name); }
function allNames() { return results.map(item => item.name); }
function labLimitMessage(count) { return `Artist Lab에는 한 번에 최대 ${fmt(LAB_SEND_LIMIT)}명까지 전송할 수 있습니다. 현재 ${fmt(count)}명이 선택되어 있습니다.`; }
function updateSelectedCount() {
  const count = selectedNames().length, over = count > LAB_SEND_LIMIT;
  $('#selectedCount').textContent = results.length ? `${count} / ${results.length} 선택` : '';
  $('#selectedCount').classList.toggle('over-limit', over);
  $('#sendLabCount').textContent = results.length ? `${fmt(count)}명` : '';
  $('#sendLabBtn').classList.toggle('over-limit', over);
  $('#sendLabBtn').title = over ? labLimitMessage(count) : '선택한 작가를 Artist Lab › 단일 작가 테스트 › 직접 입력 (Pool 저장 안 함)에 넣습니다';
}
async function copyNames(names) {
  if (!names.length) { toast('복사할 작가를 선택해 주세요.', true); return; }
  const text = names.join('\n');
  try { await navigator.clipboard.writeText(text); }
  catch { const area = document.createElement('textarea'); area.value = text; document.body.append(area); area.select(); document.execCommand('copy'); area.remove(); }
  toast(`${names.length}명을 복사했습니다.`);
}
async function saveTxt() {
  const names = selectedNames();
  if (!names.length) { toast('저장할 작가를 선택해 주세요.', true); return; }
  const query = lastJob ? $('#query').value.trim() : '';
  if (!window.pywebview?.api?.save_text) { toast('TXT 저장은 Finder 앱 창에서만 사용할 수 있습니다.', true); return; }
  try {
    const saved = await window.pywebview.api.save_text(names, query);
    if (saved.saved) toast(`${saved.count}명을 ${saved.file}에 저장했습니다.`);
    else if (!saved.cancelled) toast(saved.error || 'TXT 저장에 실패했습니다.', true);
  } catch (e) { toast(`TXT 저장 실패: ${e}`, true); }
}
function showLabMessage(text, error) { const node = $('#labMessage'); node.textContent = text; node.classList.toggle('error', error); node.classList.remove('hidden'); }
async function sendLab() {
  const names = selectedNames();
  if (!names.length) { toast('전송할 작가를 선택해 주세요.', true); return; }
  // Checked before any request: results, checkboxes and the search stay as they are.
  if (names.length > LAB_SEND_LIMIT) { const message = labLimitMessage(names.length); showLabMessage(message, true); toast(message, true); return; }
  $('#sendLabBtn').disabled = true;
  try {
    const result = await api('/api/artist-lab/send', {method: 'POST', body: JSON.stringify({artists: names, artist_lab_url: $('#labUrl').value.trim()})});
    showLabMessage(`${result.artists.length}명을 Artist Lab › 단일 작가 테스트 › 직접 입력 (Pool 저장 안 함)에 넣었습니다. 생성은 시작하지 않았습니다.`, false);
    checkLab(true);
  } catch (e) {
    showLabMessage(e.message, true); toast(e.message, true); checkLab(true);
  } finally { $('#sendLabBtn').disabled = false; }
}
async function clearHistory() {
  if (!await confirmReset('수집 기록을 모두 삭제할까요?\n이전에 발견한 작가 목록만 비웁니다. 작품 수 캐시와 Artist Lab 데이터는 그대로입니다.')) return;
  try { const data = await api('/api/history', {method: 'DELETE'}); setHistoryCount(data.seen_count); toast('수집 기록을 초기화했습니다.'); }
  catch (e) { toast(e.message, true); }
}
async function clearCountCache() {
  if (!await confirmReset('작품 수 캐시를 모두 삭제할까요?\n필요한 정보는 다음 검색 때 다시 가져옵니다.')) return;
  try { const data = await api('/api/post-count-cache', {method: 'DELETE'}); setCountCacheCount(data.post_count_cache_count); toast('작품 수 캐시를 초기화했습니다.'); }
  catch (e) { toast(e.message, true); }
}

/* The window shows only this local page: no external links, no dropped URLs/files. */
document.addEventListener('click', e => {
  const link = e.target.closest?.('a[href]');
  if (link && new URL(link.href, location.href).origin !== location.origin) { e.preventDefault(); toast('이 앱에서는 외부 페이지를 열지 않습니다.', true); }
});
['dragover', 'drop'].forEach(type => document.addEventListener(type, e => e.preventDefault()));

$('#collectBtn').addEventListener('click', collect);
$('#againBtn').addEventListener('click', collect);
$('#stopBtn').addEventListener('click', stop);
$('#query').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) collect(); });
$$('#targetCount,#pageScope,#sortMode,#sfwOnly,#excludeSeen,#excludePool,#labUrl,#minPostEnabled,#minPostCount').forEach(node => node.addEventListener('change', () => { updateHints(); saveSettingsSoon(); }));
$('#labUrl').addEventListener('change', () => checkLab(true));
$('#checkLabBtn').addEventListener('click', () => checkLab(false));
$('#clearHistoryBtn').addEventListener('click', clearHistory);
$('#clearCountCacheBtn').addEventListener('click', clearCountCache);
$('#moreBtn').addEventListener('click', showMore);
$('#selectAllBtn').addEventListener('click', () => { $$('#resultBody input').forEach(n => n.checked = true); updateSelectedCount(); });
$('#clearAllBtn').addEventListener('click', () => { $$('#resultBody input').forEach(n => n.checked = false); updateSelectedCount(); });
$('#resultBody').addEventListener('change', updateSelectedCount);
$('#copySelectedBtn').addEventListener('click', () => copyNames(selectedNames()));
$('#copyAllBtn').addEventListener('click', () => copyNames(allNames()));
$('#saveTxtBtn').addEventListener('click', saveTxt);
$('#sendLabBtn').addEventListener('click', sendLab);

async function init() {
  try {
    const data = await api('/api/bootstrap');
    fillSettings(data.settings); setHistoryCount(data.seen_count); setCountCacheCount(data.post_count_cache_count);
    $('#danbooruState').title = data.danbooru_host;
    if (data.storage_warning) toast(data.storage_warning, true);
  } catch (e) { toast(e.message, true); }
  updateHints(); checkLab(true);
  setInterval(() => checkLab(true), 10000);
}
init();
