from __future__ import annotations

from urllib.parse import urlparse

import httpx

ARTIST_LAB_TITLE = "NovelAI Artist Lab"
NOT_RUNNING = "Artist Lab에 연결할 수 없습니다. Artist Lab을 실행한 뒤 다시 시도하세요."
PATCH_MISSING = "실행 중인 Artist Lab이 Finder 연동이 없는 이전 버전입니다. 최신 NovelAI Artist Lab으로 업데이트해 주세요."


class ArtistLabError(RuntimeError):
    pass


def validate_lab_url(value: str) -> str:
    """Only a loopback Artist Lab is accepted; localhost is pinned to 127.0.0.1 because
    Artist Lab binds IPv4 loopback only."""
    parsed = urlparse(value.strip())
    if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost"}:
        raise ArtistLabError("Artist Lab 주소는 로컬 http://127.0.0.1:포트 형식만 허용합니다.")
    if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {"", "/"}:
        raise ArtistLabError("Artist Lab 주소 형식이 올바르지 않습니다.")
    try:
        port = parsed.port
    except ValueError as exc:
        raise ArtistLabError("Artist Lab 포트가 올바르지 않습니다.") from exc
    if not port:
        raise ArtistLabError("Artist Lab 포트를 입력해 주세요.")
    return f"http://127.0.0.1:{port}"


class ArtistLabClient:
    """Talks only to the Finder routes added to Artist Lab. It never reads /api/state
    (prompts, settings, jobs) and never calls Pool, settings or generation routes."""

    DIRECT_INPUT_PATH = "/api/integrations/danbooru-artist-finder/direct-input"
    POOL_NAMES_PATH = "/api/integrations/danbooru-artist-finder/pool-names"

    def __init__(self, base_url: str, *, transport=None, timeout: float = 3.0):
        self.base_url = validate_lab_url(base_url)
        self.client = httpx.Client(transport=transport, timeout=timeout, follow_redirects=False)

    def close(self) -> None:
        self.client.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _is_artist_lab(self) -> bool:
        """Identify an older Artist Lab without the Finder routes by its FastAPI title (no user data involved)."""
        try:
            response = self.client.get(f"{self.base_url}/openapi.json")
            return response.status_code == 200 and response.json().get("info", {}).get("title") == ARTIST_LAB_TITLE
        except (httpx.HTTPError, ValueError, AttributeError):
            return False

    def status(self) -> dict:
        try:
            response = self.client.get(f"{self.base_url}{self.DIRECT_INPUT_PATH}")
        except httpx.HTTPError:
            return {"connected": False, "integration_ready": False, "message": "연결 안 됨"}
        if response.status_code == 200:
            return {"connected": True, "integration_ready": True, "message": "연결됨"}
        if response.status_code == 404 and self._is_artist_lab():
            return {"connected": True, "integration_ready": False, "message": "연결됨 · Artist Lab 업데이트 필요"}
        return {"connected": False, "integration_ready": False, "message": f"Artist Lab이 아닌 응답 ({response.status_code})"}

    def pool_names(self) -> list[str]:
        """Read-only list of Artist Pool names."""
        try:
            response = self.client.get(f"{self.base_url}{self.POOL_NAMES_PATH}")
        except httpx.HTTPError as exc:
            raise ArtistLabError(NOT_RUNNING) from exc
        if response.status_code == 404:
            raise ArtistLabError(PATCH_MISSING)
        try:
            response.raise_for_status()
            names = response.json()["artists"]
        except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
            raise ArtistLabError("Artist Lab의 Artist Pool 이름 목록을 읽을 수 없습니다.") from exc
        return [name for name in names if isinstance(name, str) and name.strip()]

    def send_direct_input(self, artists: list[str]) -> dict:
        if not artists:
            raise ArtistLabError("전송할 작가를 선택해 주세요.")
        try:
            response = self.client.post(f"{self.base_url}{self.DIRECT_INPUT_PATH}", json={"artists": artists})
        except httpx.HTTPError as exc:
            raise ArtistLabError(NOT_RUNNING) from exc
        if response.status_code == 404:
            raise ArtistLabError(PATCH_MISSING)
        try:
            response.raise_for_status()
            result = response.json()
            if not isinstance(result.get("artists"), list):
                raise ValueError("artists missing")
            return result
        except (httpx.HTTPError, ValueError, AttributeError) as exc:
            raise ArtistLabError("Artist Lab이 전송을 처리하지 못했습니다.") from exc
