"""Danbooru Artist Finder backend."""

