from __future__ import annotations

APP_NAME = "Danbooru Artist Finder"
APP_VERSION = "1.1.0"

# The only place the Danbooru host is defined. Any https://*.donmai.us mirror works.
DEFAULT_DANBOORU_HOST = "https://shima.donmai.us"
# Artist Lab's own entry point binds 127.0.0.1:8766 (NovelAI-Artist-Lab/app.py).
DEFAULT_ARTIST_LAB_URL = "http://127.0.0.1:8766"

# Finder's internal backend: loopback only, first free port from DEFAULT_PORT.
BIND_HOST = "127.0.0.1"
DEFAULT_PORT = 8770
PORT_SCAN_LIMIT = 10

# 탐색 범위: pages per search. None = until Danbooru has no more results.
PAGE_SCOPES: dict[str, int | None] = {"10": 10, "25": 25, "50": 50, "all": None}
PAGE_SIZE = 200  # Danbooru's maximum posts per page
# Only the fields Finder needs; keeps each page response small.
POST_FIELDS = "id,tag_string_artist"

# Danbooru 전체 등록 작품 수: /tags.json?search[name_comma]=... returns many tags per request.
TAG_FIELDS = "name,post_count"
POST_COUNT_BATCH_SIZE = 100  # names per request (~2 KB URL)
POST_COUNT_CACHE_TTL_SECONDS = 24 * 60 * 60

# Network: one request, then at most MAX_RETRIES retries with these waits.
REQUEST_TIMEOUT_SECONDS = 20.0
MAX_RETRIES = 5
BACKOFF_SECONDS = (1.0, 2.0, 4.0, 6.0, 8.0)
RETRY_AFTER_CAP_SECONDS = 60.0
# Pause between pages; requests are always sequential.
PAGE_DELAY_SECONDS = 1.0

USER_AGENT = f"Danbooru-Artist-Finder/{APP_VERSION} (local desktop read-only client)"
