from __future__ import annotations

import random
import re
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, Iterable

from .config import PAGE_SIZE
from .danbooru import DanbooruError, SearchStopped

# Any rating metatag the user typed: rating:g, rating:s,q, -rating:e, rating:general ...
RATING_RE = re.compile(r"(?<!\S)-?rating:\S+", re.IGNORECASE)
ORDER_RE = re.compile(r"(?<!\S)-?order:\S+", re.IGNORECASE)

REASON_SCOPE = "탐색 범위 완료"
REASON_END = "검색 결과 종료"
REASON_TARGET = "목표 작가 수 도달"
REASON_USER = "사용자 중지"
REASON_NETWORK = "네트워크 오류"
REASON_ERROR = "검색 오류"
REASON_PAGE_LIMIT = "Danbooru 페이지 한도 도달"

SORT_MODES = ("frequency", "post_count", "first_seen", "random")


# Danbooru search metatags (qualifier:value). Their values are never rewritten.
METATAG_RE = re.compile(
    r"^[-~]?(?:rating|order|user|approver|commenter|comm|noter|noteupdater|artcomm|commentaryupdater|flagger|"
    r"appealer|upvote|downvote|fav|ordfav|favgroup|ordfavgroup|pool|ordpool|note|comment|commentary|id|source|"
    r"status|filetype|disapproved|parent|child|search|embedded|md5|width|height|mpixels|ratio|score|upvotes|"
    r"downvotes|filesize|date|age|limit|pixiv|pixiv_id|is|has|exif|ai|unaligned|gentags|arttags|chartags|"
    r"copytags|metatags|[a-z_]*count):",
    re.IGNORECASE,
)


def has_rating_tag(query: str) -> bool:
    return bool(RATING_RE.search(query))


def normalize_query(query: str) -> str:
    """Search box text -> Danbooru tag query.

    Without a separating comma the text is already a Danbooru query (tags separated by
    spaces; a comma inside a metatag value like `rating:g,s` does not count) and only extra
    whitespace is collapsed. With commas, each comma-separated item is one tag and the spaces
    inside it become one "_": "blue hair, long hair" -> "blue_hair long_hair". Metatag items
    (rating:g, -rating:e, order:score, id:>100 ...) are kept as typed, and a comma glued to
    a metatag value stays part of it (rating:g,s).
    """
    tokens = query.split()
    if not any("," in token and (not METATAG_RE.match(token) or token.endswith(",")) for token in tokens):
        return " ".join(tokens)
    tags: list[str] = []
    glue = False  # the previous item was a single metatag token with no space before this comma
    for raw in query.split(","):
        item = raw.strip()
        if glue and item and raw == item and " " not in item:
            tags[-1] += f",{item}"
            continue
        glue = False
        if not item:
            continue
        if METATAG_RE.match(item):
            tokens = item.split()
            tags.extend(tokens)
            glue = len(tokens) == 1 and raw == raw.rstrip()
        else:
            tags.append("_".join(item.split()))
    return " ".join(tags)


def build_query(query: str, sfw_only: bool) -> str:
    """normalize_query, then: SFW on + no rating metatag in the query -> append rating:g.
    A rating the user typed (rating:g/s/q/e, a negated or comma form) is kept as is."""
    normalized = normalize_query(query)
    if sfw_only and not has_rating_tag(normalized):
        normalized = f"{normalized} rating:g".strip()
    return normalized


def uses_id_cursor(query: str) -> bool:
    """Danbooru's default order is newest id first; then `page=b<id>` keeps paging past
    page 1000 and does not shift when new posts arrive. An order: metatag needs numbers."""
    return not ORDER_RE.search(query)


def extract_artist_tags(post: dict) -> list[str]:
    """Only Danbooru's artist-category field; general/copyright/character/meta are separate
    fields and are never read."""
    value = post.get("tag_string_artist", "") if isinstance(post, dict) else ""
    if not isinstance(value, str):
        return []
    seen: set[str] = set()
    result: list[str] = []
    for name in value.split():
        key = name.casefold()
        if key not in seen:
            seen.add(key)
            result.append(name)
    return result


def sort_artists(items: list[dict], mode: str, rng: random.Random | None = None) -> list[dict]:
    result = list(items)
    if mode == "frequency":
        # Ties keep the order of first discovery.
        return sorted(result, key=lambda item: (-item["count"], item["first_seen"]))
    if mode == "post_count":
        # Danbooru 전체 등록 작품 수, highest first; unknown counts go last (never treated as 0).
        # Ties: more appearances in this search, then first discovered.
        return sorted(result, key=lambda item: (item.get("post_count") is None, -(item.get("post_count") or 0),
                                                -item["count"], item["first_seen"]))
    if mode == "first_seen":
        return sorted(result, key=lambda item: item["first_seen"])
    if mode == "random":
        (rng or random.SystemRandom()).shuffle(result)
        return result
    raise ValueError("지원하지 않는 정렬 방식입니다.")


def stops_at_target(sort_mode: str) -> bool:
    """Only 처음 발견된 순 may end the scan once the target is reached. 검색 결과 내 등장 빈도,
    Danbooru 전체 등록 작품 수 and 랜덤 need every page in the scope, otherwise counts / the
    candidate pool are skewed."""
    return sort_mode == "first_seen"


def passes_min_post_count(item: dict, min_post_count: int) -> bool:
    """최소 등록 작품 수: keep post_count >= minimum. An unknown count (lookup failed) is kept
    and shown as unknown rather than silently treated as 0."""
    count = item.get("post_count")
    return min_post_count <= 0 or count is None or count >= min_post_count


@dataclass
class CollectionResult:
    query: str
    artists: list[dict]  # the first target_count of `ranked`
    total_found: int
    pages: int
    posts: int
    requests: int
    stop_reason: str
    partial: bool = False
    error: str = ""
    error_kind: str = ""
    eligible: int = 0  # candidates left after the minimum post count filter
    filtered_out: int = 0
    count_requests: int = 0
    count_error: str = ""
    ranked: list[dict] = field(default_factory=list)  # every candidate left, in final order (더 보기)
    counts_used: bool = False  # post_count was needed (post_count sort or minimum filter) and looked up


@dataclass
class Collector:
    client: object
    sleep: Callable[[float], None]
    page_delay: float = 1.0
    rng: random.Random | None = None
    _counts: OrderedDict[str, dict] = field(default_factory=OrderedDict, init=False)

    def snapshot(self) -> list[dict]:
        return [dict(item) for item in self._counts.values()]

    def collect(
        self,
        *,
        query: str,
        target_count: int,
        page_limit: int | None,
        sort_mode: str,
        excluded: Iterable[str] = (),
        stop_requested: Callable[[], bool] = lambda: False,
        progress: Callable[[dict], None] = lambda _: None,
        min_post_count: int = 0,
        post_counts=None,
    ) -> CollectionResult:
        """Sequential page scan. Ends at: the page scope (10/25/50; none for 전체), an empty
        page (no more results), the user's stop, a failed request, or - only for
        first_seen - the target count after the current page is fully processed.

        Danbooru 전체 등록 작품 수 (post_counts: PostCountLookup) is looked up only when it is
        needed - sorting by post_count or filtering by min_post_count - and then for every
        candidate (filter first, then sort). Other searches never look counts up, so they never
        add cache entries. `ranked` keeps the whole final order (random: shuffled once)."""
        if sort_mode not in SORT_MODES:
            raise ValueError("지원하지 않는 정렬 방식입니다.")
        self._counts = OrderedDict()
        excluded_keys = {name.casefold() for name in excluded}
        cursor_paging = uses_id_cursor(query)
        pages = posts = requests = 0
        page: int | str = 1
        reason, error, error_kind = REASON_END, "", ""

        def report(phase: str) -> None:
            progress({"phase": phase, "page": pages + 1 if phase != "searching" else pages,
                      "pages": pages, "posts": posts, "artists": len(self._counts)})

        while page_limit is None or pages < page_limit:
            if stop_requested():
                reason = REASON_USER
                break
            report("connecting")
            requests += 1
            try:
                page_posts = self.client.fetch_posts(query=query, page=page, limit=PAGE_SIZE, progress=progress)
            except SearchStopped:
                reason = REASON_USER
                break
            except DanbooruError as exc:
                if exc.kind == "page_limit":
                    reason = REASON_PAGE_LIMIT
                else:
                    network = exc.kind not in {"forbidden", "client"}
                    reason, error, error_kind = (REASON_NETWORK if network else REASON_ERROR), str(exc), exc.kind
                break
            if not page_posts:
                reason = REASON_END
                break
            pages += 1
            for post in page_posts:
                posts += 1
                for name in extract_artist_tags(post):
                    key = name.casefold()
                    if key in excluded_keys:
                        continue
                    if key not in self._counts:
                        self._counts[key] = {"name": name, "count": 0, "first_seen": len(self._counts)}
                    self._counts[key]["count"] += 1
            report("searching")
            try:
                reached = stops_at_target(sort_mode) and self._enough(target_count, min_post_count, post_counts,
                                                                       stop_requested, progress)
            except SearchStopped:
                reason = REASON_USER
                break
            if reached:
                reason = REASON_TARGET
                break
            if page_limit is not None and pages >= page_limit:
                reason = REASON_SCOPE
                break
            if stop_requested():
                reason = REASON_USER
                break
            ids = [item["id"] for item in page_posts if isinstance(item, dict) and isinstance(item.get("id"), int)]
            page = f"b{min(ids)}" if cursor_paging and ids else pages + 1
            self.sleep(self.page_delay)

        candidates = self.snapshot()
        needs_counts = sort_mode == "post_count" or min_post_count > 0
        counts: dict[str, int] = {}
        if needs_counts and post_counts is not None:
            names = [item["name"] for item in candidates]
            if reason in {REASON_USER, REASON_NETWORK, REASON_ERROR}:
                counts = post_counts.cached(names)  # stopped / failed: no more requests
            else:
                try:
                    counts = post_counts.lookup(names, stop_requested=stop_requested, progress=progress)
                except SearchStopped:
                    reason = REASON_USER
                    counts = post_counts.cached(names)
        for item in candidates:
            item["post_count"] = counts.get(item["name"])
        kept = [item for item in candidates if passes_min_post_count(item, min_post_count)] if needs_counts else candidates
        ranked = sort_artists(kept, sort_mode, self.rng)
        return CollectionResult(
            query=query, artists=ranked[:target_count], ranked=ranked, counts_used=needs_counts,
            total_found=len(candidates), pages=pages, posts=posts,
            requests=requests, stop_reason=reason, partial=reason in {REASON_USER, REASON_NETWORK, REASON_ERROR},
            error=error, error_kind=error_kind, eligible=len(kept), filtered_out=len(candidates) - len(kept),
            count_requests=post_counts.requests if post_counts is not None else 0,
            count_error=post_counts.error if post_counts is not None else "",
        )

    def _enough(self, target_count, min_post_count, post_counts, stop_requested, progress) -> bool:
        """first_seen: has the target been reached? With the minimum post count filter only
        candidates that pass it count, so their post counts are looked up page by page."""
        if len(self._counts) < target_count:
            return False
        if min_post_count <= 0 or post_counts is None:
            return True
        names = [item["name"] for item in self._counts.values()]
        counts = post_counts.lookup(names, stop_requested=stop_requested, progress=progress)
        return sum(passes_min_post_count({"post_count": counts.get(name)}, min_post_count) for name in names) >= target_count


def artists_to_text(names: Iterable[str]) -> str:
    cleaned = [str(name).strip() for name in names if str(name).strip()]
    return "\n".join(cleaned) + ("\n" if cleaned else "")


_UNSAFE_FILENAME_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f\s_]+')
_RESERVED_NAMES = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}


def safe_filename_part(value: str, max_length: int = 40) -> str:
    """Windows-safe fragment for a file name (no reserved characters/names, no trailing dot)."""
    text = _UNSAFE_FILENAME_RE.sub("_", value.strip())
    text = text.strip("._ ")[:max_length].rstrip("._ ")
    return "" if text.casefold() in _RESERVED_NAMES else text


def txt_filename(query: str = "", now: datetime | None = None) -> str:
    stamp = (now or datetime.now()).strftime("%Y%m%d-%H%M%S")
    part = safe_filename_part(query)
    return f"danbooru-artists-{part}-{stamp}.txt" if part else f"danbooru-artists-{stamp}.txt"
