from __future__ import annotations

import json
import os
import threading
from datetime import datetime
from pathlib import Path


class LocalStorage:
    def __init__(self, root: Path):
        self.data_dir = root / "data"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.warning = ""

    def _atomic_json(self, path: Path, value) -> None:
        temp = path.with_suffix(path.suffix + ".tmp")
        with self._lock:
            temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(temp, path)

    @property
    def seen_path(self) -> Path:
        return self.data_dir / "seen_artists.json"

    @property
    def settings_path(self) -> Path:
        return self.data_dir / "settings.json"

    def load_seen(self) -> set[str]:
        with self._lock:
            if not self.seen_path.exists():
                return set()
            try:
                payload = json.loads(self.seen_path.read_text(encoding="utf-8"))
                values = payload.get("artists", []) if isinstance(payload, dict) else payload
                if not isinstance(values, list) or not all(isinstance(item, str) for item in values):
                    raise ValueError("artists must be a list of names")
                return {item.strip() for item in values if item.strip()}
            except (OSError, json.JSONDecodeError, ValueError, TypeError):
                stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
                backup = self.seen_path.with_name(f"seen_artists.corrupt-{stamp}.json")
                try:
                    os.replace(self.seen_path, backup)
                    self.warning = f"손상된 수집 기록을 {backup.name}(으)로 이동하고 빈 기록으로 시작했습니다."
                except OSError:
                    self.warning = "수집 기록을 읽을 수 없어 빈 기록으로 시작했습니다."
                return set()

    def add_seen(self, names: list[str]) -> None:
        existing = self.load_seen()
        existing.update(name for name in names if name)
        self._atomic_json(self.seen_path, {"artists": sorted(existing, key=str.casefold)})

    def clear_seen(self) -> None:
        self._atomic_json(self.seen_path, {"artists": []})

    @property
    def post_count_cache_path(self) -> Path:
        return self.data_dir / "artist_post_count_cache.json"

    def load_post_counts(self) -> dict[str, dict]:
        """{name: {"post_count": int, "fetched_at": unix seconds}}. Invalid entries are
        dropped; an unreadable file is moved aside and the cache starts empty."""
        with self._lock:
            if not self.post_count_cache_path.exists():
                return {}
            try:
                payload = json.loads(self.post_count_cache_path.read_text(encoding="utf-8"))
                entries = payload.get("artists") if isinstance(payload, dict) else None
                if not isinstance(entries, dict):
                    raise ValueError("artists must be an object")
            except (OSError, ValueError, TypeError):
                stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
                try:
                    os.replace(self.post_count_cache_path, self.post_count_cache_path.with_name(f"artist_post_count_cache.corrupt-{stamp}.json"))
                except OSError:
                    pass
                return {}
            return {name: {"post_count": entry["post_count"], "fetched_at": float(entry["fetched_at"])}
                    for name, entry in entries.items()
                    if isinstance(name, str) and isinstance(entry, dict) and isinstance(entry.get("post_count"), int)
                    and not isinstance(entry.get("post_count"), bool) and entry["post_count"] >= 0
                    and isinstance(entry.get("fetched_at"), (int, float)) and not isinstance(entry.get("fetched_at"), bool)}

    def save_post_counts(self, entries: dict[str, dict]) -> None:
        """Entries are never pruned here: an expired (stale) entry stays until it is fetched
        again or the user clears the cache."""
        self._atomic_json(self.post_count_cache_path, {"artists": entries})

    def clear_post_counts(self) -> None:
        """작품 수 캐시 초기화: empties artist_post_count_cache.json only (works on a damaged file too)."""
        self._atomic_json(self.post_count_cache_path, {"artists": {}})

    def load_settings(self, defaults: dict) -> dict:
        with self._lock:
            try:
                raw = json.loads(self.settings_path.read_text(encoding="utf-8"))
                return {**defaults, **raw} if isinstance(raw, dict) else dict(defaults)
            except (OSError, ValueError, TypeError):
                return dict(defaults)

    def save_settings(self, settings: dict) -> None:
        self._atomic_json(self.settings_path, settings)

